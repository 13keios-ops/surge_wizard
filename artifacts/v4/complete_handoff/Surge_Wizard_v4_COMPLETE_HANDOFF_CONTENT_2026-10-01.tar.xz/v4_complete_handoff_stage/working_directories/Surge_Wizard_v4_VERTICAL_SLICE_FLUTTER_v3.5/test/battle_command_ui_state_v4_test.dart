import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/encounter_data_v4.dart';
import 'package:surge_wizard/core/hex_coord_v4.dart';
import 'package:surge_wizard/models/battle_v4_models.dart';
import 'package:surge_wizard/screens/battle_preview_controller_v4.dart';

void main() {
  test('category opens second-level skill ring', () {
    const encounter = EncounterDefinitionV4(
      id: 'test', name: 'test', columns: 9, rows: 7,
      partyIds: ['wizard'], enemies: [], terrain: {}, gold: 0, essence: 0,
    );
    final c = BattlePreviewControllerV4(encounter: encounter, seed: 1);
    c.selectCategory(V4ActionCategory.attack);
    expect(c.interactionMode, V4InteractionMode.skill);
    expect(c.currentSkills.length, 3);
    expect(c.selectedSkillId, 'wizard.dart');
  });

  test('move mode exposes reachable hexes and returns to command after move', () {
    const encounter = EncounterDefinitionV4(
      id: 'test', name: 'test', columns: 9, rows: 7,
      partyIds: ['wizard'],
      enemies: [EncounterSpawnV4(instanceId: 'g', templateId: 'enemy_goblin_scout', anchor: HexCoord(6, 3))],
      terrain: {}, gold: 0, essence: 0,
    );
    final c = BattlePreviewControllerV4(encounter: encounter, seed: 2);
    c.enterMoveMode();
    expect(c.interactionMode, V4InteractionMode.move);
    final target = c.reachableHexes.first;
    c.handleBoardTap(target);
    expect(c.interactionMode, V4InteractionMode.command);
    expect(c.engine.movementUsedThisActivation, isTrue);
  });
}
