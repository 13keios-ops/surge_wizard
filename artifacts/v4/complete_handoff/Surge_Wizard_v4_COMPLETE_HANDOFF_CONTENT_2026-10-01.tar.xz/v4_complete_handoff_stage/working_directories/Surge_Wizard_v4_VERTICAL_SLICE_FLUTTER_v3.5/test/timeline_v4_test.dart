import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/combat_state_v4.dart';
import 'package:surge_wizard/core/hex_coord_v4.dart';
import 'package:surge_wizard/core/status_system_v4.dart';
import 'package:surge_wizard/core/timeline_v4.dart';

CombatUnitV4 unit({int speed = 100}) => CombatUnitV4(
      id: 'u',
      name: 'u',
      team: CombatTeamV4.party,
      anchor: const HexCoord(0, 0),
      stats: UnitStatsV4(
        maxHp: 10,
        speed: speed,
        move: 2,
        evasion: 11,
        fortitude: 11,
        resolve: 11,
        brace: 11,
      ),
    );

void main() {
  test('base delay follows speed formula', () {
    expect(effectiveDelayV4(baseDelay: 100, unit: unit(speed: 100)), 100);
    expect(effectiveDelayV4(baseDelay: 100, unit: unit(speed: 125)), 80);
  });

  test('slow and haste net and clamp', () {
    final u = unit();
    applyStatusV4(
      target: u,
      type: StatusTypeV4.slowed,
      duration: 2,
      potency: 20,
    );
    applyStatusV4(
      target: u,
      type: StatusTypeV4.haste,
      duration: 2,
      potency: 15,
    );

    expect(effectiveDelayV4(baseDelay: 100, unit: u), 105);
  });

  test('adding slow does not retroactively change already scheduled time', () {
    final u = unit();
    u.nextActionTime = 80;

    applyStatusV4(
      target: u,
      type: StatusTypeV4.slowed,
      duration: 2,
      potency: 20,
    );

    expect(u.nextActionTime, 80);
  });
}
