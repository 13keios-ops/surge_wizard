import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/combat_board_v4.dart';
import 'package:surge_wizard/core/combat_state_v4.dart';
import 'package:surge_wizard/core/hex_coord_v4.dart';
import 'package:surge_wizard/core/spell_catalog_v4.dart';
import 'package:surge_wizard/core/target_resolver_v4.dart';

CombatUnitV4 caster() => CombatUnitV4(
      id: 'w',
      name: 'w',
      team: CombatTeamV4.party,
      anchor: const HexCoord(1, 3),
      stats: const UnitStatsV4(
        maxHp: 60,
        speed: 100,
        move: 2,
        evasion: 11,
        fortitude: 11,
        resolve: 11,
        brace: 11,
      ),
    );

void main() {
  const resolver = TargetResolverV4();
  final board = CombatBoardV4();

  test('Burst7 has seven cells away from border', () {
    final cells = resolver.resolveHexes(
      spell: SpellCatalogV4.fireball,
      caster: caster(),
      target: const HexCoord(4, 3),
      board: board,
    );
    expect(cells.length, 7);
  });

  test('line extends toward target and stays in board', () {
    final cells = resolver.resolveHexes(
      spell: SpellCatalogV4.iceLance,
      caster: caster(),
      target: const HexCoord(6, 3),
      board: board,
    );
    expect(cells, isNotEmpty);
    expect(cells.every(board.valid), isTrue);
    expect(cells.length, lessThanOrEqualTo(5));
  });

  test('chain selects target then nearest jumps', () {
    final w = caster();
    final enemies = [
      CombatUnitV4(
        id: 'a',
        name: 'a',
        team: CombatTeamV4.enemy,
        anchor: const HexCoord(4, 3),
        stats: const UnitStatsV4(
          maxHp: 10,
          speed: 100,
          move: 2,
          evasion: 11,
          fortitude: 11,
          resolve: 11,
          brace: 11,
        ),
      ),
      CombatUnitV4(
        id: 'b',
        name: 'b',
        team: CombatTeamV4.enemy,
        anchor: const HexCoord(5, 3),
        stats: const UnitStatsV4(
          maxHp: 10,
          speed: 100,
          move: 2,
          evasion: 11,
          fortitude: 11,
          resolve: 11,
          brace: 11,
        ),
      ),
      CombatUnitV4(
        id: 'c',
        name: 'c',
        team: CombatTeamV4.enemy,
        anchor: const HexCoord(6, 3),
        stats: const UnitStatsV4(
          maxHp: 10,
          speed: 100,
          move: 2,
          evasion: 11,
          fortitude: 11,
          resolve: 11,
          brace: 11,
        ),
      ),
    ];

    final result = resolver.resolveUnits(
      spell: SpellCatalogV4.chainSpark,
      caster: w,
      target: const HexCoord(4, 3),
      board: board,
      units: [w, ...enemies],
    );

    expect(result.map((u) => u.id).toList(), ['a', 'b', 'c']);
  });
}
