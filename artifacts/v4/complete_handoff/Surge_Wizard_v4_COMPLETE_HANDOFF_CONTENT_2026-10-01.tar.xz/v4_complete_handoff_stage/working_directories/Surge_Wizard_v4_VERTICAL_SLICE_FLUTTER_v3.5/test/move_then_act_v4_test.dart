import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/combat_engine_v4.dart';
import 'package:surge_wizard/core/combat_state_v4.dart';
import 'package:surge_wizard/core/hex_coord_v4.dart';

CombatUnitV4 unit(
  String id,
  CombatTeamV4 team,
  HexCoord at,
) =>
    CombatUnitV4(
      id: id,
      name: id,
      team: team,
      anchor: at,
      stats: const UnitStatsV4(
        maxHp: 30,
        speed: 100,
        move: 2,
        evasion: 11,
        fortitude: 11,
        resolve: 11,
        brace: 11,
      ),
      primaryModifier: 3,
      weaponPower: 5,
      mastery: 1,
    );

void main() {
  test('voluntary move keeps activation open for action', () {
    final engine = CombatEngineV4(
      seed: 7,
      units: [
        unit('a', CombatTeamV4.party, const HexCoord(1, 2)),
        unit('b', CombatTeamV4.enemy, const HexCoord(4, 2)),
      ],
    );

    engine.beginNextActivation();
    final moved = engine.moveActiveTo(const HexCoord(2, 2));

    expect(moved, isTrue);
    expect(engine.activationOpen, isTrue);
    expect(engine.movementUsedThisActivation, isTrue);
  });

  test('second voluntary move in same activation is rejected', () {
    final engine = CombatEngineV4(
      seed: 8,
      units: [
        unit('a', CombatTeamV4.party, const HexCoord(1, 2)),
        unit('b', CombatTeamV4.enemy, const HexCoord(6, 2)),
      ],
    );

    engine.beginNextActivation();
    expect(engine.moveActiveTo(const HexCoord(2, 2)), isTrue);
    expect(engine.moveActiveTo(const HexCoord(3, 2)), isFalse);
  });
}
