import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/seeded_rng_v4.dart';

void main() {
  test('same seed reproduces the same sequence', () {
    final a = SeededRngV4(23092026);
    final b = SeededRngV4(23092026);

    final seqA = List.generate(20, (_) => a.nextUint32());
    final seqB = List.generate(20, (_) => b.nextUint32());

    expect(seqA, seqB);
  });

  test('restore reproduces the next roll', () {
    final rng = SeededRngV4(42);
    rng.nextUint32();
    final saved = rng.state;
    final expected = rng.nextUint32();

    rng.restore(saved);
    expect(rng.nextUint32(), expected);
  });
}
