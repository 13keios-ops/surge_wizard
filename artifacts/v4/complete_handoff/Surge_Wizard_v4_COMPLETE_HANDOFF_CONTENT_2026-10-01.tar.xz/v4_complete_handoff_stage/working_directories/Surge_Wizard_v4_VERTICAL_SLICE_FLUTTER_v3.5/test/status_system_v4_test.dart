import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/combat_state_v4.dart';
import 'package:surge_wizard/core/hex_coord_v4.dart';
import 'package:surge_wizard/core/status_system_v4.dart';

CombatUnitV4 makeUnit({
  ControlProfileV4 profile = ControlProfileV4.normal,
  Set<StatusTypeV4> immunities = const {},
}) =>
    CombatUnitV4(
      id: 'u',
      name: 'u',
      team: CombatTeamV4.enemy,
      anchor: const HexCoord(0, 0),
      controlProfile: profile,
      immunities: immunities,
      stats: const UnitStatsV4(
        maxHp: 100,
        speed: 100,
        move: 2,
        evasion: 11,
        fortitude: 11,
        resolve: 11,
        brace: 11,
      ),
    );

void main() {
  test('burning stacks to 3 and refreshes duration by max', () {
    final u = makeUnit();
    applyStatusV4(
      target: u,
      type: StatusTypeV4.burning,
      duration: 2,
      tickPower: 3,
    );
    applyStatusV4(
      target: u,
      type: StatusTypeV4.burning,
      duration: 1,
      stacks: 3,
      tickPower: 5,
    );

    final burn = u.status(StatusTypeV4.burning)!;
    expect(burn.stacks, 3);
    expect(burn.remainingActivations, 2);
    expect(burn.tickPower, 5);
  });

  test('immune unit rejects poison', () {
    final u = makeUnit(immunities: {StatusTypeV4.poisoned});
    applyStatusV4(
      target: u,
      type: StatusTypeV4.poisoned,
      duration: 3,
    );
    expect(u.has(StatusTypeV4.poisoned), isFalse);
  });

  test('boss root converts to slow', () {
    final u = makeUnit(profile: ControlProfileV4.boss);
    applyStatusV4(
      target: u,
      type: StatusTypeV4.rooted,
      duration: 1,
    );
    expect(u.has(StatusTypeV4.rooted), isFalse);
    expect(u.status(StatusTypeV4.slowed)?.potency, 25);
  });

  test('poison healing penalty caps at 40%', () {
    final u = makeUnit();
    applyStatusV4(
      target: u,
      type: StatusTypeV4.poisoned,
      duration: 3,
      stacks: 2,
    );
    expect(poisonHealingPenaltyPercentV4(u), 40);
  });
}
