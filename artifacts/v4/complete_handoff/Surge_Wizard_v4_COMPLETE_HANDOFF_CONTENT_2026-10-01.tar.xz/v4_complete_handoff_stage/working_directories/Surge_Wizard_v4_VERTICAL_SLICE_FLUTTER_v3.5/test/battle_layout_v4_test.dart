import 'dart:ui';

import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/battle_layout_v4.dart';

void main() {
  group('HexGeometryV4', () {
    test('center hex burst contains seven cells away from edge', () {
      final geometry = HexGeometryV4(const Size(676, 302));
      final cells = geometry.burst7(const HexCoord(4, 3));
      expect(cells.length, 7);
    });

    test('all standard board coordinates are valid', () {
      for (var col = 0; col < BattleLayoutV4.columns; col++) {
        for (var row = 0; row < BattleLayoutV4.rows; row++) {
          expect(HexCoord(col, row).isValid, isTrue);
        }
      }
    });

    test('hit test resolves a hex center to itself', () {
      final geometry = HexGeometryV4(const Size(676, 302));
      const expected = HexCoord(3, 3);
      expect(geometry.hitTest(geometry.center(expected)), expected);
    });
  });
}
