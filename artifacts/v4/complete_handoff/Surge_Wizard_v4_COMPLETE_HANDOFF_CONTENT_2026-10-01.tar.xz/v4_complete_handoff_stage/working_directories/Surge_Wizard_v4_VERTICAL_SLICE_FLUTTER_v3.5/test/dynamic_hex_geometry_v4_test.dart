import 'dart:ui';

import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/battle_layout_v4.dart';

void main() {
  test('10x7 geometry hit-tests the tenth column', () {
    final geometry = HexGeometryV4(
      const Size(720, 300),
      columns: 10,
      rows: 7,
    );
    const target = HexCoord(9, 3);
    expect(geometry.hitTest(geometry.center(target)), target);
  });

  test('8x6 geometry rejects coordinates outside encounter board', () {
    final geometry = HexGeometryV4(
      const Size(700, 280),
      columns: 8,
      rows: 6,
    );
    expect(
      geometry.neighbors(const HexCoord(7, 5))
          .every((c) => c.isValidFor(8, 6)),
      isTrue,
    );
  });
}
