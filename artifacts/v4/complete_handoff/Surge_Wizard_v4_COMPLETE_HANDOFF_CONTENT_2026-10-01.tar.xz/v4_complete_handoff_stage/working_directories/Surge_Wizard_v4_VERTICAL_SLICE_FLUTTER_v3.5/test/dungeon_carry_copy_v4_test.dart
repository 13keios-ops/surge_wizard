import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/dungeon_run_state_v4.dart';
import 'package:surge_wizard/core/vertical_slice_catalog_v4.dart';

void main() {
  test('carry copy is deep and preserves retry safe state', () {
    final wizard = VerticalSliceCatalogV4.wizard();
    final original = DungeonCarryStateV4.fromParty([wizard], hpPotions: 2);
    original.party['wizard']!.startBarrier = 10;
    final copy = original.copy();
    copy.party['wizard']!.hp = 1;
    copy.hpPotions = 0;
    expect(original.party['wizard']!.hp, wizard.stats.maxHp);
    expect(original.party['wizard']!.startBarrier, 10);
    expect(original.hpPotions, 2);
  });
}
