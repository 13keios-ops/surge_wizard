import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/combat_engine_v4.dart';
import 'package:surge_wizard/core/combat_state_v4.dart';
import 'package:surge_wizard/core/hex_coord_v4.dart';
import 'package:surge_wizard/core/status_system_v4.dart';

CombatUnitV4 makeUnit(
  String id,
  CombatTeamV4 team,
  HexCoord coord, {
  int hp = 50,
  int speed = 100,
  int armor = 0,
}) =>
    CombatUnitV4(
      id: id,
      name: id,
      team: team,
      anchor: coord,
      stats: UnitStatsV4(
        maxHp: hp,
        speed: speed,
        move: 2,
        evasion: 11,
        fortitude: 11,
        resolve: 11,
        brace: 11,
        armor: armor,
      ),
      primaryModifier: 3,
      weaponPower: 10,
      mastery: 1,
    );

void main() {
  test('same seed and same actions produce same attack result', () {
    CombatEngineV4 build() => CombatEngineV4(
          seed: 999,
          units: [
            makeUnit('a', CombatTeamV4.party, const HexCoord(1, 1)),
            makeUnit('b', CombatTeamV4.enemy, const HexCoord(2, 1)),
          ],
        );

    final a = build()..beginNextActivation();
    final b = build()..beginNextActivation();

    final ra = a.basicAttack(attackerId: 'a', targetId: 'b');
    final rb = b.basicAttack(attackerId: 'a', targetId: 'b');

    expect(ra.dice, rb.dice);
    expect(ra.hit, rb.hit);
    expect(ra.damage, rb.damage);
  });

  test('barrier absorbs after guarded reduction', () {
    final engine = CombatEngineV4(
      seed: 123,
      units: [
        makeUnit('a', CombatTeamV4.party, const HexCoord(1, 1)),
        makeUnit('b', CombatTeamV4.enemy, const HexCoord(2, 1)),
      ],
    );

    final target = engine.unit('b');
    applyStatusV4(
      target: target,
      type: StatusTypeV4.guarded,
      duration: 2,
      potency: 20,
    );
    target.barriers.add(BarrierV4(
      amount: 999,
      remainingActivations: 2,
      sourceId: 'test',
    ));

    engine.beginNextActivation();
    engine.basicAttack(attackerId: 'a', targetId: 'b');

    expect(target.hp, target.stats.maxHp);
    expect(target.barrierTotal, lessThan(999));
  });

  test('rooted blocks voluntary movement', () {
    final engine = CombatEngineV4(
      seed: 1,
      units: [
        makeUnit('a', CombatTeamV4.party, const HexCoord(1, 1)),
        makeUnit('b', CombatTeamV4.enemy, const HexCoord(5, 5)),
      ],
    );

    final actor = engine.unit('a');
    applyStatusV4(
      target: actor,
      type: StatusTypeV4.rooted,
      duration: 1,
    );

    engine.beginNextActivation();
    final moved = engine.moveActiveTo(const HexCoord(2, 1));

    expect(moved, isFalse);
    expect(actor.anchor, const HexCoord(1, 1));
  });

  test('leaving engagement consumes one enemy reaction', () {
    final engine = CombatEngineV4(
      seed: 42,
      units: [
        makeUnit('a', CombatTeamV4.party, const HexCoord(2, 2), speed: 110),
        makeUnit('b', CombatTeamV4.enemy, const HexCoord(3, 2), speed: 90),
      ],
    );

    engine.beginNextActivation();
    engine.moveActiveTo(const HexCoord(1, 2));

    expect(engine.unit('b').reactionAvailable, isFalse);
    expect(
      engine.log.any((e) => e.kind.startsWith('opportunity_')),
      isTrue,
    );
  });
}
