import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/combat_engine_v4.dart';
import 'package:surge_wizard/core/combat_state_v4.dart';
import 'package:surge_wizard/core/hex_coord_v4.dart';
import 'package:surge_wizard/core/spell_catalog_v4.dart';

CombatUnitV4 makeUnit(
  String id,
  CombatTeamV4 team,
  HexCoord anchor, {
  int hp = 60,
  int mp = 100,
}) =>
    CombatUnitV4(
      id: id,
      name: id,
      team: team,
      anchor: anchor,
      stats: UnitStatsV4(
        maxHp: hp,
        maxMp: mp,
        speed: 100,
        move: 2,
        evasion: 11,
        fortitude: 11,
        resolve: 11,
        brace: 11,
      ),
      primaryModifier: 3,
      mastery: 2,
    );

void main() {
  test('fireball affects multiple units inside Burst7', () {
    final engine = CombatEngineV4(
      seed: 1234,
      units: [
        makeUnit('w', CombatTeamV4.party, const HexCoord(1, 3)),
        makeUnit('a', CombatTeamV4.enemy, const HexCoord(5, 3)),
        makeUnit('b', CombatTeamV4.enemy, const HexCoord(5, 4)),
        makeUnit('c', CombatTeamV4.enemy, const HexCoord(8, 6)),
      ],
    );

    engine.beginNextActivation();

    final result = engine.castSpellAction(
      casterId: 'w',
      spell: SpellCatalogV4.fireball,
      targetHex: const HexCoord(5, 3),
    );

    expect(result.preview.targetIds, contains('a'));
    expect(result.preview.targetIds, contains('b'));
    expect(result.preview.targetIds, isNot(contains('c')));
  });

  test('arcane shield adds barrier and consumes mana', () {
    final engine = CombatEngineV4(
      seed: 77,
      units: [
        makeUnit('w', CombatTeamV4.party, const HexCoord(1, 3)),
        makeUnit('e', CombatTeamV4.enemy, const HexCoord(6, 3)),
      ],
    );

    engine.beginNextActivation();
    final before = engine.unit('w').mp;

    engine.castSpellAction(
      casterId: 'w',
      spell: SpellCatalogV4.arcaneShield,
      targetHex: const HexCoord(1, 3),
    );

    expect(engine.unit('w').barrierTotal, greaterThan(0));
    expect(engine.unit('w').mp, lessThan(before));
  });
}
