import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/combat_state_v4.dart';
import 'package:surge_wizard/core/hex_coord_v4.dart';
import 'package:surge_wizard/core/seeded_rng_v4.dart';
import 'package:surge_wizard/core/spell_catalog_v4.dart';
import 'package:surge_wizard/core/surge_cast_resolver_v4.dart';

CombatUnitV4 wizard() => CombatUnitV4(
      id: 'w',
      name: 'w',
      team: CombatTeamV4.party,
      anchor: const HexCoord(1, 1),
      stats: const UnitStatsV4(
        maxHp: 60,
        maxMp: 100,
        speed: 100,
        move: 2,
        evasion: 11,
        fortitude: 11,
        resolve: 14,
        brace: 11,
      ),
      primaryModifier: 3,
      mastery: 2,
    );

void main() {
  const resolver = SurgeCastResolverV4();

  test('same seed gives same stability result', () {
    final a = resolver.resolve(
      spell: SpellCatalogV4.fireball,
      caster: wizard(),
      rng: SeededRngV4(555),
    );
    final b = resolver.resolve(
      spell: SpellCatalogV4.fireball,
      caster: wizard(),
      rng: SeededRngV4(555),
    );

    expect(a.dice, b.dice);
    expect(a.outcome, b.outcome);
    expect(a.total, b.total);
  });

  test('circle 2 normal stability DC is 11', () {
    final result = resolver.resolve(
      spell: SpellCatalogV4.fireball,
      caster: wizard(),
      rng: SeededRngV4(1),
    );
    expect(result.dc, 11);
  });
}
