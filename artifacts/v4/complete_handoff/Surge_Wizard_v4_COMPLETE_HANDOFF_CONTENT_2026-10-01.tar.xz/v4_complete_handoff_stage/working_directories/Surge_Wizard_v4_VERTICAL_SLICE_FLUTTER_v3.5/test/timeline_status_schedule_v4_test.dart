import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/combat_engine_v4.dart';
import 'package:surge_wizard/core/combat_state_v4.dart';
import 'package:surge_wizard/core/hex_coord_v4.dart';
import 'package:surge_wizard/core/status_system_v4.dart';

CombatUnitV4 unit(String id, CombatTeamV4 team) => CombatUnitV4(
      id: id,
      name: id,
      team: team,
      anchor: team == CombatTeamV4.party
          ? const HexCoord(1, 1)
          : const HexCoord(6, 1),
      stats: const UnitStatsV4(
        maxHp: 30,
        speed: 100,
        move: 2,
        evasion: 11,
        fortitude: 11,
        resolve: 11,
        brace: 11,
      ),
    );

void main() {
  test('Slow affects scheduled delay before duration expires', () {
    final slowed = unit('a', CombatTeamV4.party);
    final enemy = unit('b', CombatTeamV4.enemy);

    applyStatusV4(
      target: slowed,
      type: StatusTypeV4.slowed,
      duration: 1,
      potency: 20,
    );

    final engine = CombatEngineV4(
      seed: 10,
      units: [slowed, enemy],
    );

    engine.beginNextActivation();
    engine.finishActivation(baseDelay: 100);

    expect(slowed.nextActionTime, 120);
    expect(slowed.has(StatusTypeV4.slowed), isFalse);
  });
}
