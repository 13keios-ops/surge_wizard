import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/dungeon_run_state_v4.dart';
import 'package:surge_wizard/core/vertical_slice_catalog_v4.dart';

void main() {
  test('KO revives to 1 HP after victory carry capture', () {
    final wizard = VerticalSliceCatalogV4.wizard();
    final kael = VerticalSliceCatalogV4.kael();
    kael.hp = 0;

    final carry = DungeonCarryStateV4.fromParty(
      [wizard, kael],
      hpPotions: 0,
    );

    carry.captureAfterVictory([wizard, kael]);

    expect(carry.party['kael']!.hp, 1);
  });

  test('between fight potion consumes inventory', () {
    final wizard = VerticalSliceCatalogV4.wizard();
    wizard.hp = 10;

    final carry = DungeonCarryStateV4.fromParty(
      [wizard],
      hpPotions: 2,
    );

    carry.useBetweenFightPotions([wizard]);

    expect(carry.hpPotions, lessThan(2));
    expect(carry.party['wizard']!.hp, greaterThan(10));
  });


  test('boss checkpoint restores full HP and MP floor only', () {
    final wizard = VerticalSliceCatalogV4.wizard();
    final kael = VerticalSliceCatalogV4.kael();
    wizard.hp = 8;
    wizard.mp = 22;
    kael.hp = 20;

    final carry = DungeonCarryStateV4.fromParty(
      [wizard, kael],
      hpPotions: 1,
    );

    carry.applyBossAntechamberCheckpoint(
      [wizard, kael],
      wizardMpFloor: 100,
    );

    expect(carry.party['wizard']!.hp, wizard.stats.maxHp);
    expect(carry.party['wizard']!.mp, 100);
    expect(carry.party['kael']!.hp, kael.stats.maxHp);
    expect(carry.party['wizard']!.startBarrier, 10);
    expect(carry.party['kael']!.startBarrier, 10);
    expect(carry.hpPotions, 1);
  });

  test('Ancient Focus grants MP and one-fight start barrier', () {
    final wizard = VerticalSliceCatalogV4.wizard();
    final kael = VerticalSliceCatalogV4.kael();
    wizard.mp = 70;

    final carry = DungeonCarryStateV4.fromParty(
      [wizard, kael],
      hpPotions: 0,
    );

    carry.applyAncientFocusReward(
      [wizard, kael],
      wizardMpBonus: 40,
      partyBarrier: 25,
    );

    expect(carry.party['wizard']!.mp, 110);
    expect(carry.party['wizard']!.startBarrier, 25);
    expect(carry.party['kael']!.startBarrier, 25);
  });


}
