import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/combat_engine_v4.dart';
import 'package:surge_wizard/core/combat_state_v4.dart';
import 'package:surge_wizard/core/hex_coord_v4.dart';
import 'package:surge_wizard/core/vertical_slice_catalog_v4.dart';

void main() {
  test('Kael Guard applies Guarded and schedules action', () {
    final kael = VerticalSliceCatalogV4.kael();
    final enemy = VerticalSliceCatalogV4.enemy(
      'enemy_goblin_scout',
      'g',
      const HexCoord(5, 2),
    );
    final engine = CombatEngineV4(seed: 4, units: [kael, enemy]);
    kael.nextActionTime = 0;
    enemy.nextActionTime = 20;

    expect(engine.beginNextActivation()?.id, 'kael');
    engine.kaelGuardStance();

    expect(kael.has(StatusTypeV4.guarded), isTrue);
    expect(kael.nextActionTime, greaterThan(0));
  });

  test('Nera Smoke Step relocates without opportunity and guards', () {
    final nera = VerticalSliceCatalogV4.nera();
    final enemy = VerticalSliceCatalogV4.enemy(
      'enemy_goblin_scout',
      'g',
      const HexCoord(2, 4),
    );
    final engine = CombatEngineV4(seed: 5, units: [nera, enemy]);
    nera.nextActionTime = 0;
    enemy.nextActionTime = 20;

    engine.beginNextActivation();
    final moved = engine.neraSmokeStep(const HexCoord(0, 4));

    expect(moved, isTrue);
    expect(nera.anchor, const HexCoord(0, 4));
    expect(nera.has(StatusTypeV4.guarded), isTrue);
    expect(enemy.reactionAvailable, isTrue);
  });

  test('Nera Expose rejects targets beyond range 3', () {
    final nera = VerticalSliceCatalogV4.nera();
    final enemy = VerticalSliceCatalogV4.enemy(
      'enemy_goblin_scout',
      'g',
      const HexCoord(7, 4),
    );
    final engine = CombatEngineV4(seed: 6, units: [nera, enemy]);
    nera.nextActionTime = 0;
    enemy.nextActionTime = 20;
    engine.beginNextActivation();

    expect(
      () => engine.neraExposeWeakness(targetId: 'g'),
      throwsStateError,
    );
  });
}
