import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/encounter_loader_v4.dart';

void main() {
  test('Vertical Slice JSON contains B01-B05', () async {
    final source = await File(
      'assets/data/v4_vertical_slice_encounters.json',
    ).readAsString();

    final encounters =
        const EncounterLoaderV4().decode(source);

    expect(encounters.length, 5);
    expect(encounters.first.id, 'VS_B01_GOBLIN_AMBUSH');
    expect(encounters.last.id, 'VS_B05_BONE_HEAP');
    expect(encounters[0].partyIds.length, 2);
    expect(encounters[1].partyIds.length, 3);
    expect(encounters[4].columns, 10);
  });
}
