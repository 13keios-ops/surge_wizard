import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:surge_wizard/core/encounter_loader_v4.dart';
import 'package:surge_wizard/core/headless_runner_v4.dart';

void main() {
  test('same encounter seed reproduces telemetry', () async {
    final source = await File(
      'assets/data/v4_vertical_slice_encounters.json',
    ).readAsString();

    final encounter =
        const EncounterLoaderV4().decode(source).first;
    const runner = HeadlessRunnerV4();

    final a = runner.run(encounter: encounter, seed: 23092026);
    final b = runner.run(encounter: encounter, seed: 23092026);

    expect(a.won, b.won);
    expect(a.activations, b.activations);
    expect(a.wizardMpRemaining, b.wizardMpRemaining);
    expect(a.partyHpRatio, b.partyHpRatio);
  });
}
