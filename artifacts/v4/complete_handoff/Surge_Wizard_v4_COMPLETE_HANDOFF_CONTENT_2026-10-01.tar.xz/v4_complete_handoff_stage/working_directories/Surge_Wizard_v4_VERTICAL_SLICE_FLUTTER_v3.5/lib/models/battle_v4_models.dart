import '../core/hex_coord_v4.dart';

enum V4Team { party, enemy }
enum V4UnitSize { normal, large3, huge7 }
enum V4ActionCategory { attack, control, defense, tool }
enum V4InteractionMode { command, skill, move }

extension V4ActionCategoryLabel on V4ActionCategory {
  String get label => switch (this) {
        V4ActionCategory.attack => '공격',
        V4ActionCategory.control => '제어',
        V4ActionCategory.defense => '방어',
        V4ActionCategory.tool => '도구',
      };
}

class V4SkillChoice {
  const V4SkillChoice({
    required this.id,
    required this.label,
    required this.shortLabel,
    required this.category,
  });
  final String id;
  final String label;
  final String shortLabel;
  final V4ActionCategory category;
}

class V4StatusBadge {
  const V4StatusBadge({
    required this.code,
    required this.label,
    required this.priority,
    this.stacks = 1,
  });
  final String code;
  final String label;
  final int priority;
  final int stacks;
}

class V4BattleUnit {
  const V4BattleUnit({
    required this.id,
    required this.name,
    required this.team,
    required this.anchor,
    required this.maxHp,
    required this.hp,
    required this.speed,
    this.maxMp = 0,
    this.mp = 0,
    this.size = V4UnitSize.normal,
    this.assetPath,
    this.footprint = const [],
    this.statuses = const [],
    this.barrier = 0,
    this.isPlaceholder = false,
  });

  final String id;
  final String name;
  final V4Team team;
  final HexCoord anchor;
  final int maxHp;
  final int hp;
  final int maxMp;
  final int mp;
  final int speed;
  final V4UnitSize size;
  final String? assetPath;
  final List<HexCoord> footprint;
  final List<V4StatusBadge> statuses;
  final int barrier;
  final bool isPlaceholder;

  double get hpRatio => maxHp <= 0 ? 0 : hp / maxHp;
  double get mpRatio => maxMp <= 0 ? 0 : mp / maxMp;
  Iterable<HexCoord> get occupied =>
      footprint.isEmpty ? <HexCoord>[anchor] : footprint;
}

class V4TargetPreview {
  const V4TargetPreview({
    required this.title,
    required this.lines,
  });
  final String title;
  final List<String> lines;
}
