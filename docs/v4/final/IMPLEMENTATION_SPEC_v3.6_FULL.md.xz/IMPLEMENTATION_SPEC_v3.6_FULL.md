# Surge Wizard v4 — Implementation Specification v3.6

**Scope:** Path Preview · Pre-commit Combat Preview · Detailed Combat Log · Safe Point Save/Restore

**Status:** implementation-ready specification supplement to v3.5.  
**Authority:** newer explicit user instruction > this document > v3.5 master where the topic overlaps.

---

## 1. Goal of v3.6

v3.5 made the Vertical Slice manually playable in structure. v3.6 defines the information and persistence layer needed before real device playtesting.

The implementation must make four things true:

1. A player can see **where a move will actually travel** before committing it.
2. A player can see **what an action is expected to do** before consuming MP / action time / RNG.
3. A developer or player can reconstruct **why an outcome happened** from the combat log.
4. A Vertical Slice run can survive app restarts and wipes without duplicating rewards or refunding consumed items.

This is a specification pass. It does not claim that these features have already been implemented or executed.

---

# 2. Path Preview

## 2.1 Interaction model

Current v3.5 behavior moves immediately when a reachable Hex is tapped. Replace it with a two-stage mobile-safe interaction.

```text
MOVE button
→ reachable Hexes appear
→ first tap on a reachable Hex = preview destination
→ path line + cost + risk appears
→ tap same Hex again OR press MOVE CONFIRM = commit movement
→ actor moves
→ activation remains open for Act
```

Rules:

- Tapping another reachable Hex changes the preview destination.
- Tapping an unreachable Hex clears only the destination preview; MOVE mode stays open.
- Back exits MOVE mode without moving.
- After one voluntary move, ordinary MOVE becomes unavailable for that activation.
- Rooted disables voluntary MOVE.
- Forced movement / teleport skills use their own preview and do not consume voluntary movement unless the skill definition says so.

Reason for two-stage confirmation: on a touch device, path information is only useful if the player can inspect it before movement is committed.

## 2.2 Pathfinding authority

The **engine pathfinder** is the authority. UI must never invent a visually shorter path that the engine would not use.

Add a deterministic path API:

```dart
PathResultV4 shortestPath({
  required CombatUnitV4 unit,
  required HexCoord destination,
  required Iterable<CombatUnitV4> units,
  int? budget,
});
```

`PathResultV4`:

```text
path: [start, ..., destination]
movementCost: int
remainingMovement: int
opportunityEdges: List<OpportunityRiskV4>
terrainEntries: List<TerrainEntryV4>
valid: bool
failureReason: optional enum
```

Tie-break order must be deterministic:

1. lower total movement cost
2. fewer opportunity-trigger edges
3. fewer hazard tiles
4. fewer steps
5. lexicographic Hex order `(col,row)`

This tie-break is for selecting among equally legal paths; it must not silently choose a higher movement-cost path just to avoid opportunity attacks.

## 2.3 Terrain cost

The existing board rules remain authoritative.

```text
Normal / Cover / Forest : cost 1 unless separately authored
Water                    : cost 2
Block                    : impassable
```

If later terrain adds a movement modifier, `CombatBoardV4.movementCost()` remains the single source of truth.

## 2.4 Opportunity preview

Opportunity risk is evaluated **per path edge**, not merely at the final Hex.

An opportunity trigger exists when an edge moves the actor from adjacent to an eligible enemy to non-adjacent.

Preview records:

```text
reactorId
fromHex
toHex
estimatedHitChance
estimatedDamageMinMax
```

The path is still legal even when opportunity attacks are predicted.

Nera Smoke Step / explicit Disengage / Teleport:

```text
opportunityEdges = []
```

and the path graphic uses a teleport/dashed style rather than ordinary footsteps.

## 2.5 Visual language

Do not rely on color alone.

- Reachable area: existing blue-tinted fill + subtle border.
- Preview path: solid center-to-center line with small step dots.
- Destination: outlined Hex + endpoint marker.
- Water/high-cost step: small `2` cost pip or terrain icon.
- Opportunity edge: `!` marker placed on the relevant segment.
- Telegraph overlap: warning icon on the overlapping Hex; Telegraph remains visually higher priority than movement.

Layer order remains:

```text
terrain
passive grid
hazard
movement reachable
path line
selected target / skill area
enemy telegraph
units
floating information
UI overlay
```

Enemy Telegraph always wins visual priority over the move path.

## 2.6 Path Preview panel

While previewing movement, lower-right Context Preview shows:

```text
MOVE · (col,row)
Cost 2 / Move 3
Remaining 1
Opportunity ×1
Water ×1
```

If no risk:

```text
Opportunity 없음
```

If destination intersects a known enemy Telegraph:

```text
⚠ Enemy Telegraph
```

## 2.7 Path Preview acceptance tests

Required tests:

1. shortest path respects Water cost.
2. Block never appears in a path.
3. occupied Hex never appears as a destination/path node unless explicitly allowed by a skill.
4. same state always returns the same tied path.
5. opportunity risk is attached to the correct edge.
6. Nera Smoke Step produces no opportunity risk.
7. Root prevents voluntary path preview/commit.
8. preview does not mutate actor position, RNG, reaction state, or timeline.
9. second tap/confirm commits exactly the path previously previewed if state did not change.
10. if state changes before confirmation, path is recalculated and invalid confirmation is rejected.

---

# 3. Pre-commit Combat Preview

## 3.1 Principle

Preview is **pure calculation**.

It must not:

- consume RNG
- change HP/MP
- apply Status
- move timeline
- consume reactions
- alter Barrier
- mutate the combat log

The same preview can be requested repeatedly without changing the eventual combat result.

## 3.2 Probability engine

Use exact 3d6 enumeration, not Monte Carlo.

```text
6 × 6 × 6 = 216 outcomes
```

Create a shared probability helper used by UI and AUTO scoring:

```dart
ProbabilityBreakdownV4 attackProbability(...)
ProbabilityBreakdownV4 effectProbability(...)
CastProbabilityV4 castProbability(...)
```

This avoids AUTO and UI disagreeing about the same chance.

## 3.3 Attack preview

For direct attacks show:

```text
Hit 74%
Damage 12–15
Crit 0.5%
Target EVA 13
```

Damage range is the normal non-critical deterministic range after known static mitigation:

```text
90% variance → mitigation → element multiplier → Guarded
through
110% variance → mitigation → element multiplier → Guarded
```

Barrier is shown separately rather than pretending it is part of armor:

```text
Barrier 10 → estimated HP damage 2–5
```

Crit range may be shown on detailed view:

```text
Crit 18–22
```

Natural 3 / natural 18 rules must be included in the displayed chance.

## 3.4 Cover preview

For direct ranged actions:

```text
Cover +2 EVA
```

must appear as a reason line.

Example:

```text
Hit 58%
EVA 12 + Cover 2 = 14
```

AoE shapes that do not use Cover in the implemented resolver should not display this modifier.

## 3.5 Spell Stability preview

Before cast, show distribution over the stability roll:

```text
Stable/Perfect 94%
Unstable 5%
Surge 1%
DC 11
```

Perfect may be folded into Stable in compact UI and split in Detailed view.

Detailed:

```text
Perfect 0.5%
Stable 93.5%
Unstable 5.1%
Surge 0.9%
```

Round display to one decimal when under 10%, otherwise whole percent is acceptable in compact UI.

## 3.6 Spell direct-hit preview

If an attack spell performs a direct hit check, display both checks distinctly:

```text
Cast 안정 94%
Hit 74%
Damage 15–19
Burn 63%
```

Do not multiply these into one opaque “overall success” number in the default UI. The player should understand what can fail.

## 3.7 Effect preview

For control/status effects:

```text
Root 68% vs FORT 14
Duration 1 Activation
```

Boss conversion must be previewed before commitment.

Example:

```text
Root → Slow 25%
Boss Control Conversion
```

If immune:

```text
IMMUNE
```

and effect chance is not shown as if the effect could land.

## 3.8 AoE / multi-target preview

The board preview must enumerate actual affected units from the current resolver.

Context panel:

```text
Targets 3
Goblin A  Hit 83% · 14–17
Goblin B  Hit 74% · 13–16
Gargoyle  Hit 58% · 10–13
```

On small screens, display the first 3 and `+N`.

Board markers:

- target Hexes outlined.
- each affected unit gets a small target marker.
- friendly targets use a distinct icon/stripe, not only a different color.

## 3.9 Friendly Fire

The preview engine supports friendly fire even if many current spells have `friendlyFire=false`.

For any action whose definition permits ally damage/effects:

```text
ALLY HIT ×1
```

must be shown before commit.

If a damaging action will affect one or more allies, require explicit second confirmation:

```text
실행
→ “아군 1명이 범위에 있습니다”
→ 그래도 시전
```

Exceptions:

- self-cost explicitly stated in the skill definition.
- actions whose only friendly effect is beneficial.

AUTO Balanced policy must apply a large negative friendly-fire score unless an authored skill policy explicitly permits the trade.

## 3.10 Timeline preview

Before committing an action, show a **ghost next-position** for the active actor in the top timeline.

Only calculate deterministic action delay effects known before RNG:

- base delay
- Speed
- current Slow/Haste
- authored guaranteed timeline shifts

Do **not** pretend to predict RNG-dependent Stagger or Surge displacement as certain.

Compact text:

```text
Next: +113
```

## 3.11 Preview data model

Recommended pure model:

```dart
class CombatPreviewV4 {
  ActionDescriptorV4 action;
  String actorId;
  HexCoord? targetHex;
  List<TargetPreviewV4> targets;
  CastProbabilityV4? cast;
  int manaCost;
  int effectiveDelay;
  int predictedNextActionTime;
  List<String> warnings;
  bool requiresFriendlyFireConfirmation;
}
```

`TargetPreviewV4`:

```text
targetId
relation: enemy / ally / self
hitChance
effectChance
damageMin
damageMax
critDamageMin
critDamageMax
coverBonus
defenseType
defenseValue
statusName
statusDuration
bossConversion
immune
barrierAbsorbMinMax
```

## 3.12 Combat Preview acceptance tests

1. preview does not consume RNG state.
2. direct ranged preview includes Cover +2.
3. natural 3/18 are reflected in probability.
4. 216-outcome helper matches AUTO probability helper exactly.
5. Barrier changes HP-damage estimate without changing raw damage estimate.
6. Boss Root preview reports Slow conversion.
7. immunity is displayed as immunity, not 0% pseudo-roll.
8. Burst7 lists exactly the units the resolver would affect.
9. friendly-fire confirmation is required only for harmful ally impact.
10. predicted timeline position matches `effectiveDelayV4()`.
11. changing target immediately updates all values without state mutation.

---

# 4. Detailed Combat Log

## 4.1 Two layers

Keep the engine event stream machine-readable and build the user/developer log on top of it.

```text
CombatEventV4           = low-level deterministic engine event
CombatLogEntryV4        = grouped human-readable entry
CombatLogActivationV4   = one actor activation group
```

Do not replace structured engine data with preformatted Korean strings.

## 4.2 Activation grouping

A full log is grouped by activation:

```text
T=225 · Wizard
  MOVE (1,3) → (2,3), Cost 1
  Fire Bolt → Goblin Scout
  Stability 3d6 [4,5,3] +4 =16 vs DC10 · Stable
  Hit 3d6 [3,4,5] +4 =16 vs EVA13 · Hit
  Damage 15 → Armor 1 → 14
  Burning 3d6 ... · Success · 2 Activations
  Next action T=319
```

This should let a developer reconstruct a bug without needing a debugger.

## 4.3 Required structured fields

Each low-level entry should be able to carry, when relevant:

```text
combatTime
activationIndex
actorId
actionId
targetId
targetHex
kind
rolls
naturalTotal
bonusBreakdown
defenseType
defenseValue
rawDamage
variancePermille
criticalMultiplier
armorOrMr
weaknessResistanceMultiplier
guardedReduction
barrierBefore
barrierAbsorbed
hpBefore
hpAfter
mpBefore
mpAfter
statusBeforeAfter
timelineBeforeAfter
rngStateBefore (debug only)
rngStateAfter  (debug only)
messageKey
```

Do not expose RNG state in normal player UI; retain it in developer/export detail.

## 4.4 Log detail levels

Accessibility / settings:

### Minimal

```text
Wizard → Goblin · 14 피해
Bone Heap · Bone Sweep 예고
Kael · 회피
```

### Normal (default)

```text
Fire Bolt · Hit 16 vs EVA 13 · 14 피해 · Burning
```

### Detailed

Shows dice, bonuses, mitigation, timeline changes and conversion details.

The setting changes presentation only, not the underlying stored events.

## 4.5 UI

Existing bottom combat toast remains a one-line latest-event surface.

Tap the toast/log icon:

- open a right-side drawer or modal sheet sized for landscape.
- newest activation visible first in compact mode.
- user can expand an activation.
- filters: All / Damage / Status / Timeline / System.
- `Copy Debug Log` is development-build only.

The log must not cover the entire tactical board by default while the player is selecting an action.

## 4.6 Log retention

During battle:

- keep full current-battle structured log.

Between battles:

- normal release save does not need to persist every combat roll.
- keep summary telemetry only.
- development builds may export the full log as JSON.

For a crash report / QA replay, the preferred packet is:

```text
encounterId
runSeed
attempt
initial carry snapshot
input/action sequence
engine event log
final RNG state
```

## 4.7 Combat Log acceptance tests

1. every committed action belongs to exactly one activation group.
2. damage log includes HP before/after and Barrier absorption.
3. status conversion is logged explicitly.
4. movement and opportunity events appear in chronological order.
5. same seed + same actions produces byte-equivalent structured event content excluding wall-clock metadata.
6. Minimal/Normal/Detailed render from the same underlying data.
7. release log never shows internal RNG state.

---

# 5. Safe Point Save / Restore

## 5.1 Scope

v4 first implementation supports **between-encounter / safe-point saves**, not arbitrary mid-action combat saves.

Mid-combat app termination restarts the encounter from the latest checkpoint state, but consumables already used in that unfinished attempt remain consumed.

This matches the established wipe rule:

```text
HP/MP checkpoint state restores
used consumables do not
no gold loss
```

## 5.2 Separate checkpoint state from durable run state

This distinction is required to prevent potion-refund exploits.

### Checkpoint snapshot

Restored on wipe/relaunch:

```text
checkpointId
currentEncounterId
party HP
party MP
start Barrier / authored checkpoint buffs
party roster
position in route
```

### Durable run state

Not rolled back on wipe:

```text
saveRevision
runSeed
attempt count
gold
essence
HP Potion count
consumed durable items
completed encounter IDs
claimed reward IDs
recruited companion flags
optional-route flags
Ancient Focus flag if earned
story/run flags
```

On defeat:

```text
restore checkpoint party snapshot
KEEP current durable potion count
KEEP committed rewards/flags
increment attempt
```

## 5.3 Save triggers

Write save immediately after these events:

1. new run creation.
2. encounter victory and reward commit.
3. entering an explicit Safe Point.
4. choosing B04 Optional vs B05 direct route.
5. consuming an HP Potion or another durable consumable.
6. obtaining Ancient Focus or another persistent run reward.
7. defeat/wipe transition.
8. app lifecycle pause if dirty state exists.

HP/MP damage during a fight does not need to be written continuously in v4. The encounter restarts after app termination.

## 5.4 Reward idempotency

Never award the same encounter twice because of a crash between victory screen and transition.

Use IDs:

```text
completedEncounterIds
claimedRewardIds
```

Victory transaction conceptually:

```text
if rewardId not claimed:
  add Gold/Essence/item/flag
  add rewardId to claimedRewardIds
mark encounter completed
write durable save
then show/leave victory screen
```

If the app dies after the write, reload sees the claimed ID and does not duplicate the reward.

## 5.5 Save schema v1

Recommended JSON shape:

```json
{
  "schemaVersion": 1,
  "saveRevision": 17,
  "runId": "uuid-or-stable-run-id",
  "runSeed": 23092026,
  "attempt": 2,
  "route": {
    "currentEncounterId": "VS_B05_BONE_HEAP",
    "checkpointId": "BROKEN_ARCHIVE_ANTECHAMBER",
    "completedEncounterIds": ["VS_B01_GOBLIN_AMBUSH", "VS_B02_RUIN_COURTYARD", "VS_B03_ARCHIVE_HALL"],
    "claimedRewardIds": ["reward.B01", "reward.B02", "reward.B03"],
    "tookOptionalB04": false
  },
  "resources": {
    "gold": 734,
    "essence": 32,
    "hpPotions": 1
  },
  "checkpointParty": {
    "wizard": {"hp": 60, "mp": 100, "startBarrier": 10},
    "kael": {"hp": 102, "mp": 0, "startBarrier": 10},
    "nera": {"hp": 72, "mp": 0, "startBarrier": 10}
  },
  "flags": {
    "neraRecruited": true,
    "ancientFocus": false
  }
}
```

Do not serialize transient Status effects from a finished battle unless a future authored mechanic explicitly carries them between battles.

## 5.6 Storage implementation

The repository already depends on `shared_preferences`, so v4 can begin with a versioned JSON string repository without introducing a new database dependency.

Recommended keys:

```text
surge_wizard_v4_save_primary
surge_wizard_v4_save_backup
```

Write strategy:

```text
1. encode new JSON with saveRevision +1
2. copy currently valid primary to backup
3. write new primary
4. read-back decode/validate
5. mark save clean in memory
```

On load:

```text
try primary
→ schema validation
→ if invalid, try backup
→ if both invalid, report recoverable save error and offer New Run
```

Do not silently create a new run over a corrupted save.

## 5.7 Schema migration

Create:

```text
RunSaveV4
RunSaveCodecV4
RunSaveRepositoryV4
RunSaveMigrationV4
```

Rules:

- `schemaVersion == current`: decode normally.
- older known version: migrate step-by-step.
- newer unknown version: refuse destructive load; tell user the save was created by a newer game version.
- migration must never reduce potion count or duplicate rewards.

## 5.8 Combat restart seed

A retry must not accidentally become a deterministic identical script if the user changes nothing, unless that is intentionally desired for debugging.

Use:

```text
encounterSeed = hash(runSeed, encounterId, attempt)
```

The current prototype formula may remain temporarily, but production should centralize it in one deterministic seed function.

For QA replay:

```text
runSeed + attempt + action sequence
```

is enough to reconstruct combat RNG.

## 5.9 Safe Point UI

At a Safe Point show a short confirmation, not a blocking save-management screen:

```text
안전 지점
HP 회복
마력 최소 100
진행 저장됨
```

Autosave icon/text may appear briefly.

Do not require manual save slots for the Vertical Slice.

## 5.10 Save/Restore acceptance tests

1. JSON roundtrip produces equivalent run state.
2. corrupted primary loads valid backup.
3. both invalid do not silently overwrite.
4. potion used in a failed encounter remains consumed after restore.
5. HP/MP restore to checkpoint values after defeat.
6. gold is not lost on wipe.
7. reward cannot be claimed twice after relaunch.
8. B03 checkpoint correctly stores Full HP / Wizard MP floor / Barrier 10.
9. B04 Ancient Focus correctly survives to B05 start.
10. optional route choice survives app restart.
11. attempt increments and changes derived encounter seed.
12. unknown newer schema is rejected safely.
13. v1 migration test fixture remains in repository permanently.

---

# 6. Suggested file split for implementation

Keep the existing ~300-line split rule.

```text
lib/core/pathfinder_v4.dart
lib/core/combat_probability_v4.dart
lib/core/combat_preview_v4.dart
lib/core/combat_log_v4.dart
lib/core/combat_log_formatter_v4.dart
lib/core/run_save_v4.dart
lib/core/run_save_codec_v4.dart
lib/core/run_save_repository_v4.dart
lib/core/run_save_migration_v4.dart

lib/screens/battle_preview_path_v4.dart
lib/screens/battle_preview_prediction_v4.dart

lib/widgets/path_preview_v4.dart
lib/widgets/combat_prediction_panel_v4.dart
lib/widgets/combat_log_panel_v4.dart
lib/widgets/autosave_indicator_v4.dart

test/pathfinder_v4_test.dart
test/combat_probability_v4_test.dart
test/combat_preview_v4_test.dart
test/combat_log_v4_test.dart
test/run_save_codec_v4_test.dart
test/run_save_repository_v4_test.dart
test/run_save_migration_v4_test.dart
```

Do not duplicate 3d6 probability code in the AUTO planner after `combat_probability_v4.dart` exists. Refactor AUTO to use the shared helper.

---

# 7. Implementation order

Recommended order to minimize rework:

```text
1. deterministic pathfinder + tests
2. shared 3d6 probability helper
3. pure CombatPreviewV4 model
4. Path Preview UI
5. Combat Prediction UI
6. structured Combat Log
7. Log panel / detail levels
8. RunSave schema + codec
9. repository primary/backup behavior
10. Vertical Slice host integration
11. local flutter analyze/test
12. Dart headless baseline
13. real-device layout/touch QA
```

The save layer should not be written first because the combat/run model is still being given the final preview/log interfaces in this pass.

---

# 8. Definition of Done for v3.6 implementation

v3.6 implementation is not “done” merely because widgets render.

It is done when all of the following are true:

- Move destination is previewed before commit.
- displayed path is engine-authoritative.
- opportunity risk is per-edge and visible without relying on color alone.
- action preview consumes zero RNG/state.
- Hit/Effect/Stability chances use the same 216-outcome helper as AUTO.
- AoE target list matches the actual resolver.
- harmful friendly fire receives explicit warning/confirmation.
- timeline ghost uses the same delay function as the engine.
- structured combat log can explain every damage/status result.
- log presentation supports Minimal/Normal/Detailed without changing raw data.
- Safe Point save persists across app restart.
- consumables are not refunded by wipe/force-close.
- rewards are idempotent.
- corrupted primary save can recover from backup.
- Flutter/Dart analyze/test are actually run locally and their outputs are committed as validation evidence.

---

# 9. Next specification after v3.6

Once these interfaces are fixed, the next design/implementation-spec pass should focus on:

```text
A. real equipment/stat pipeline into CombatUnitV4
B. prepared-spell loadout and spellbook UI
C. enemy AI archetype policy beyond the Vertical Slice fixtures
D. encounter reward / loot / essence progression integration
E. world-map → encounter → reward → hub state-machine persistence
```

Do not jump to broad campaign implementation until v3.6 local Flutter validation is complete enough to prove the core combat UX is stable.
